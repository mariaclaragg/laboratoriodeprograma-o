#include <stdio.h>
#include <string.h>

int main() {
    int n, i;
    char nomes[5][50];


    int idade[5];
    int fumante[5];
    int historico[5];
    int pontos[5];

    printf("SISTEMA DE RISCO CARDIOVASCULAR\n");
    printf("Quantos pacientes deseja cadastrar (1 a 5)? ");
    scanf("%d", &n);

        while (n < 1 || n > 5) {
            printf("Valor invalido! Digite entre 1 e 5: ");
            scanf("%d", &n);
    }

        for (i = 0; i < n; i++) {
            printf("Cadastro do Paciente %d \n", i + 1);

            printf("Nome: ");
            scanf(" ");
            fgets(nomes[i], 50, stdin);

            printf("Idade: ");
            scanf("%d", &idade[i]);

        printf("E fumante? (1- Sim e 0- Nao): ");
        scanf("%d", &fumante[i]);

        printf("Possui historico familiar? (1- Sim e 0- Nao): ");
        scanf("%d", &historico[i]);
    }


        for (i = 0; i < n; i++) {
            pontos[i] = 0;


        if (idade[i] >= 50) {
            pontos[i] += 2;
        } else if (idade[i] >= 40) {
            pontos[i] += 1;
        }

        if (fumante[i] == 1) {
            pontos[i] += 3;
        }

        if (historico[i] == 1) {
            pontos[i] += 2;
        }
    }

    printf("RESULTADOS FINAIS\n");

    for (i = 0; i < n; i++) {
        printf("Paciente: %s\n", nomes[i]);
        printf("Pontuacao total: %d pontos\n", pontos[i]);

        printf("Classificacao de Risco: ");
        if (pontos[i] <= 1) {
            printf("BAIXO\n");
        } else if (pontos[i] <= 3) {
            printf("MODERADO\n");
        } else {
            printf("ALTO\n");
        }
    }

    return 0;
}
