#include <stdio.h>

int main(void) {
    int numero;

    printf("Digite um numero inteiro: ");
    scanf("%d", &numero);

    printf("Valor digitado: %d\n", numero);
    printf("Endereco de memoria: %p\n", (void *)&numero);

    return 0;
}
