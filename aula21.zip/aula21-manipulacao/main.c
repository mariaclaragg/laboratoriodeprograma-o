#include <stdio.h>

typedef struct {
    char nome[50];
    int matricula;
} Funcionario;

int main(void) {
    FILE *arquivo;
    Funcionario f;
    int i;

    for (i = 0; i < 5; i++) {
        printf("Cadastro do funcionario %d\n", i + 1);
        printf("Nome: ");
        scanf(" %49[^\n]", f.nome);

        printf("Matricula: ");
        scanf("%d", &f.matricula);

        arquivo = fopen("funcionarios.txt", "a");
        if (arquivo == NULL) {
            perror("Erro ao abrir arquivo");
            return 1;
        }

        fprintf(arquivo, "Nome: %s - Matricula: %d\n", f.nome, f.matricula);
        fclose(arquivo);
    }

    printf("\nDados gravados com sucesso!\n");
    return 0;
}
