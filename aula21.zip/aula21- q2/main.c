#include <stdio.h>

int main(void) {
    FILE *arquivo;
    int numeros[5];
    int i;
    int caractere;

    printf("Digite 5 numeros inteiros:\n");
    for (i = 0; i < 5; i++) {
        scanf("%d", &numeros[i]);
    }

    arquivo = fopen("numeros.txt", "w");
    if (arquivo == NULL) {
        perror("Erro ao abrir arquivo");
        return 1;
    }

    for (i = 0; i < 5; i++) {
        fprintf(arquivo, "%d\n", numeros[i]);
    }
    fclose(arquivo);

    printf("\nNumeros armazenados no arquivo:\n");
    arquivo = fopen("numeros.txt", "r");
    if (arquivo == NULL) {
        perror("Erro ao abrir arquivo");
        return 1;
    }

    while ((caractere = fgetc(arquivo)) != EOF) {
        putchar(caractere);
    }
    fclose(arquivo);

    return 0;
}
