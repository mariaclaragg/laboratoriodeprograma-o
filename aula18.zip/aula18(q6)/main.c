#include <stdio.h>

int calcularFatorial(int n) {
    int fat = 1;
    for (int i = 1; i <= n; i++) {
        fat = fat * i;
    }
    return fat;
}

int main(void) {
    int numero;

    printf("CALCULADORA DE FATORIAL\n");
    printf("Digite um numero: ");
    scanf("%d", &numero);

    if (numero >= 0 && numero <= 12) {
        printf("Fatorial de %d = %d\n", numero, calcularFatorial(numero));
    } else {
        printf("Numero fora do intervalo valido (0 a 12).\n");
    }

    return 0;
}
