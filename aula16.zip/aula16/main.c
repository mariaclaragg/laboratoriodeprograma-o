// questao 1

#include <stdio.h>
int main(void) {
    char palavra[50];

    int contador = 0;
        printf("Digite uma palavra: ");
        scanf("%49s", palavra);

    for (int i = 0; palavra[i] != '\0'; i++) {
            contador++;
    }
    printf("A quantidade de letras digitadas e: %d\n", contador);
return 0;
}

//questao2

#include <stdio.h>
    int main(void) {
    char nome[100];
        printf("Digite o seu nome completo: ");
            fgets(nome, sizeof(nome), stdin);
        printf("Nome informado: %s", nome);
return 0;
}

//questao 3

#include <stdio.h>
int main(void) {
    char palavra[30];
        printf("Digite uma palavra: ");
        scanf("%29s", palavra);
        printf("O primeiro caractere e: %c \n", palavra[0]);
return 0;
}

//questao 4

#include <stdio.h>
int main(void) {
    char palavra[30];
        printf("Digite uma palavra: ");
        scanf("%s", palavra);
    for (int i = 0; palavra[i] != '\0'; i++) {
        printf("%c\n", palavra[i]);
}
return 0;
}

//questao 5
#include <stdio.h>
int main(void) {
    char palavra[30];
    int vogais = 0;
        printf("Digite uma palavra (em letras minusculas): ");
        scanf("%s", palavra);
    for (int i = 0; palavra[i] != '\0'; i++) {
    char c = palavra[i];
        if (c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u') {
            vogais++;
        }
         }
printf("Quantidade de vogais: %d\n", vogais);
return 0;
}
