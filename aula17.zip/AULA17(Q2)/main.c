#include <stdio.h>
#include <string.h>

int main(void) {
    char nomeProduto[50];
    char categoria[30];
    char copiaProduto[50];
    char descricao[70] = "Produto: ";

    printf("CADASTRO\n");

    printf("Nome do produto: ");
    scanf("%s", nomeProduto);

    printf("Categoria (HARDWARE ou PERIFERICO): ");
    scanf("%s", categoria);

    strcpy(copiaProduto, nomeProduto);


    strcat(descricao, copiaProduto);

    printf("RESUMO\n");
    printf("Produto: %s\n", nomeProduto);



    printf("Caracteres: %d\n", (int)strlen(nomeProduto));


    if (strcmp(categoria, "PERIFERICO") == 0) {
        printf("Categoria: Periferico\n");
    } else if (strcmp(categoria, "HARDWARE") == 0) {
        printf("Categoria: Hardware\n");
    } else {
        printf("Categoria: %s\n", categoria);
    }

    printf("Descricao: %s\n", descricao);
    printf("Cadastro concluido!\n");

    return 0;
}
