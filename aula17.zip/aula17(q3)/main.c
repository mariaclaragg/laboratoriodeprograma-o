#include <stdio.h>
#include <string.h>

int main(void) {
    char nomeEstudante[50];
    char codigoCurso[10];
    char nomeCopia[50];
    char mensagem[70] = "Ola, ";

    printf("IDENTIFICACAO ACADEMICA\n");

    printf("Nome do estudante: ");
    scanf("%s", nomeEstudante);

    printf("Codigo do curso (CC ou SI): ");
    scanf("%s", codigoCurso);


    strcpy(nomeCopia, nomeEstudante);


    strcat(mensagem, nomeCopia);
    strcat(mensagem, "!");

    printf("RESULTADO\n");
    printf("Estudante: %s\n", nomeEstudante);

    if (strcmp(codigoCurso, "CC") == 0) {
        printf("Curso: Ciencia da Computacao\n");
    } else if (strcmp(codigoCurso, "SI") == 0) {
        printf("Curso: Sistemas de Informacao\n");
    } else {
        printf("Curso Nao Reconhecido\n");
    }

   printf("Caracteres no nome: %d\n\n", (int)strlen(nomeEstudante));

    printf("%s\n", mensagem);

    return 0;
}
