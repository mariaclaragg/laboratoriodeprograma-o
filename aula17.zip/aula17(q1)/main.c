#include <stdio.h>
#include <string.h>

int main(void) {
    char nome[50];
    char perfil[20];
    char nomeCopia[50];
    char mensagem[70] = "Bem-vindo(a), ";

    printf("CADASTRO\n");

    printf("Digite seu nome: ");
    scanf("");
    fgets(nome, 50, stdin);

    printf("Digite seu perfil (ADMIN ou COMUM): ");
    scanf("%s", perfil);


    strcpy(nomeCopia, nome);

    strcat(mensagem, nomeCopia);

    printf("DADOS CADASTRADOS \n");
    printf("Nome: %s\n", nome);


    printf("Quantidade de caracteres: %d\n", (int)strlen(nome));

    if (strcmp(perfil, "ADMIN") == 0) {
        printf("Perfil: Administrador\n");
    } else {
        printf("Perfil: Comum\n");
    }


    printf("%s!\n", mensagem);
    printf("Cadastro realizado com sucesso.\n");

    return 0;
}
