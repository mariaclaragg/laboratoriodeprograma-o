#include <stdio.h>

    int main(void) {
    int matriz[3][3];
    int pares = 0;
        printf("Digite os valores da matriz : \n");
    for(int i = 0; i < 3; i++){
    for(int j = 0; j < 3; j++){
        scanf("%d", &matriz[i][j]);
            if(matriz[i][j] % 2 == 0){
pares++;
            }
        }
    }

    printf("Quantidade de valores pares: %d \n", pares);

return 0;
 }
