#include <stdio.h>

int main(void) {
    float notas[3][2];
    float soma, media;
        for(int i = 0; i < 3; i++){
            printf("Digite a nota 1 do aluno %d: \n", i + 1);


        scanf("%f", &notas[i][0]);
        printf("Digite a nota 2 do aluno %d: \n", i + 1);
        scanf("%f", &notas[i][1]);
    }

        for(int i = 0; i < 3; i++){
            soma = notas[i][0] + notas[i][1];
            media = soma / 2.0;
            printf("Media do aluno %d: %.2f\n", i + 1, media);
    }
    return 0; }
