#include <stdio.h>
Int main(void) {
    int matriz[2][3] = {
        {10, 20, 30},
        {40, 50, 60}
    };
    int soma = 0;
        printf("Digite os elementos da matriz: \n");
    for(int i = 0; i < 2; i++){
        for(int j = 0; j < 3; j++){
            soma = soma + matriz[i][j];
        }
    }
        printf("Soma de todos os elementos: %d  \n", soma);
return 0;
 }
