#include <stdio.h>
#include <stdlib.h>
typedef struct{
char nome[50];
int idade;
float salario;
} funcionario;

int main()
{
    funcionario funcionario1, funcionario2;
    printf("Digite o nome: \n");
    scanf("%49s", funcionario1.nome);
    printf("Digite a idade: \n");
    scanf("%d", &funcionario1.idade);
    printf("Digite o salario: \n");
    scanf("%f", &funcionario1.salario);

    printf("Digite o nome: \n");
    scanf("%49s", funcionario2.nome);
    printf("Digite a idade: \n");
    scanf("%d", &funcionario2.idade);
    printf("Digite o salario: \n");
    scanf("%f", &funcionario2.salario);

    printf("Dados dos funcionarios catrados:\n");
    printf("Funcionario 1:\n");
    printf("Nome: %s | Idade: %d | Salario: %f", funcionario1.nome, funcionario1.idade, funcionario1.salario);
    printf("Funcionario 2:\n");
    printf("Nome: %s | Idade: %d | Salario: %f", funcionario2.nome, funcionario2.idade, funcionario2.salario);


    return 0;
}
